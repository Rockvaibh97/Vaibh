﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
namespace Girraj99.Models
{
    public class Location
    {   [key]
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
