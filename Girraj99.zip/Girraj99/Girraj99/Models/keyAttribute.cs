﻿
namespace Girraj99.Models
{
    internal class keyAttribute : Attribute
    {
    }
}